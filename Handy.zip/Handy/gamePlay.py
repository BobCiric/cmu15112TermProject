from cmu_112_graphics import *
import numpy as np
import random
#reference
#inspiration: https://www.youtube.com/watch?v=tBgs1b4aEMQ&ab_channel=AYAMAJ
#images: https://drive.google.com/file/d/1yNYco-Znlc5PKjq-_qcFilZp6wgGX8ft/view
#animation frame work is taken from https://www.cs.cmu.edu/~112/notes/notes-animations-part1.html
#object movement is referenced from https://www.cs.cmu.edu/~112/notes/notes-animations-part3.html#spritesheetsWithCropping
def loadImages(app):
    ## Dino ##########################################################
    app.dinos = app.loadImage('dino.png')
    app.dinos = app.scaleImage(app.dinos, 1/2)
    app.dinoList = []
    for i in [0,2,3,4]:
        app.dino = app.dinos.crop((44*i, 0, 44+44*i, 95//2))
        app.dinoList.append(app.dino)
    app.dinoDucks = app.loadImage('dino_ducking.png')
    app.dinoDucks = app.scaleImage(app.dinoDucks, 1/2)
    app.duckList = []
    for i in [0,1]:
        app.dinoDuck = app.dinoDucks.crop((59*i, 0, 59+59*i, 95//2))
        app.duckList.append(app.dinoDuck)
        app.dinoList.append(app.dinoDuck)
    app.runList = app.dinoList
    app.dinoShape = np.shape(app.dino)
    ################################################################

    ## Ground ###################################################### 
    app.ground = app.loadImage('ground.png')
    ################################################################

    ## Cloud #######################################################
    app.cloud = app.loadImage('cloud.png')
    app.cloudList = []
    app.cloudList.append(app.cloud)
    app.cloudShape = np.shape(app.cloud)
    ################################################################

    ## Cactus #######################################################
    cacti_small = app.loadImage('cacti-small.png')
    cacti_small = app.scaleImage(cacti_small,2/3)
    app.cactiList = []
    for i in [0,1,2]:
        app.cacti_small = cacti_small.crop((46*i,0,46+46*i,68))
        app.cacti_smallShape = np.shape(app.cacti_small)
        app.cactiList.append(app.cacti_small)
    app.cactiShape = np.shape(app.cacti_small)
    cacti_big = app.loadImage('cacti-big.png')
    cacti_big = app.scaleImage(cacti_big, 2/3)

    for i in [0,1,2]:
        app.cacti_big = cacti_big.crop((34*i,0,34+34*i,100))
        app.cactiList.append(app.cacti_big)
    ################################################################

    ## Bird ########################################################
    app.birds = app.loadImage('ptera.png')
    app.birds = app.scaleImage(app.birds, 1/3)
    app.birdList = []
    for i in [0,1]:
        app.bird = app.birds.crop((30*i, 0, 30+30*i, 95//2))
        app.birdList.append(app.bird)
    ################################################################

    ## Game Numbers ################################################
    app.numbers = app.loadImage('numbers.png')
    app.numList = []
    for i in range(10):
        app.num = app.numbers.crop((20*i,0,20+20*i,100))
        app.numList.append(app.num)
    ################################################################

    ## Game Over ###################################################
    app.gameOverImage = app.loadImage('game_over.png')
    app.replayIcon = app.loadImage('replay_button.png')
    app.replayIcon = app.scaleImage(app.replayIcon, 1/2)
    ################################################################

    ## Game Logo ###################################################
    app.logo = app.loadImage('logo.png')
    app.logo = app.scaleImage(app.logo, 1)
    ################################################################

def updateScore(app):
    copyScore = app.score
    app.scoreList = [app.numList[0],app.numList[0],app.numList[0],app.numList[0],app.numList[0]]
    for i in range(len(app.scoreList)):
        app.scoreList[-1-i] = app.numList[copyScore%10]
        copyScore = copyScore//10
    app.difficulty = app.score//200 + 1

def flipDino(app):
    for i in range(len(app.dinoList)):
        app.dinoList[i] = app.dinoList[i].transpose(Image.FLIP_LEFT_RIGHT)

def groundMoving(app):
    if app.dinoDirection == True:
        app.groundx -= 10 + app.difficulty
    elif app.dinoDirection == False:
        app.groundx += 10 + app.difficulty
    app.groundx = app.groundx%600

def cactusMoving(app):
    if app.dinoDirection == True:
        app.cactix -= 10 + app.difficulty
        app.cactix2 -= 10 + app.difficulty
    elif app.dinoDirection == False:
        app.cactix += 10 + app.difficulty
        app.cactix2 += 10 + app.difficulty
    if app.cactix < 0 - app.cacti_smallShape[1]//2:
        app.cactix = random.randint(app.width, app.width + 300)
        if app.difficulty <= 4:
            app.cactusInd1 = random.randint(0,2)
        elif app.difficulty >4: 
            app.cactusInd1 = random.randint(3,5)
        while abs(app.cactix - app.cactix2) < 250:    
            app.cactix = random.randint(app.width+200, app.width + 600)
    if app.cactix2 < 0 - app.cacti_smallShape[1]//2:
        app.cactix2 = random.randint(app.width+400, app.width + 600)
        if app.difficulty <= 4:
            app.cactusInd2 = random.randint(0,3)
        elif app.difficulty > 4: 
            app.cactusInd2 = random.randint(4,5)
        while abs(app.cactix2 - app.cactix) < 250:    
            app.cactix2 = random.randint(app.width+400, app.width + 600)

def cloudMoving(app):
    if app.dinoDirection == True:
        app.cloudx -= 1
    elif app.dinoDirection == False:
        app.cloudx -= 1
    if app.cloudx < 0 - app.cloudShape[1]//2:
        cloudNum = random.randint(0,3)
        app.cloudx = random.randint(app.width, app.width + 600)

def ducking(app):
    app.dinoList = app.duckList
    app.dinoList.append(app.duckList[-1])

def jumping(app):
    app.dinoY -= app.speedy * 1
    app.speedy -= app.gravity * 1
    # if app.dinoDirection == True:
    #     app.dinoX += 2
    # elif app.dinoDirection == False:
    #     app.dinoX -= 2
    if app.dinoY > 165:
        app.dinoY = 165
        app.speedy = 30
        app.dinoIsJumping = not app.dinoIsJumping

def drawBird(app, canvas):
    if app.difficulty >= 1:
        app.birdCounter = (app.birdCounter + 1)%2
        canvas.create_image(app.birdx, app.birdy, image=ImageTk.PhotoImage(app.birdList[app.birdCounter]))

def flyBird(app):
    if app.dinoDirection == True:
        app.birdx -= 13 + app.difficulty
    elif app.dinoDirection == False:
        app.birdx -= 2 + app.difficulty
    if app.birdx < 0 - 20:
        app.birdx = random.randint(app.width, app.width + 150)
        app.birdy = random.randint(100, app.height - 50)
