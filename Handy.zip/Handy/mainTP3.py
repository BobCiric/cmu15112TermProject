#TP1
import cv2
import numpy as np
from cmu_112_graphics import *
import time
from gamePlay import *
#hand gesture recognition references 
#inspiration is from https://www.youtube.com/watch?v=v-XcmsYlzjA&t=9s&ab_channel=SadaivalSingh
#inspiration code is at https://github.com/Sadaival/Hand-Gestures 
#finding the smallest enclosing circle is from https://docs.opencv.org/3.4/da/d0c/tutorial_bounding_rects_circles.html

def appStarted(app):
    app.prev_frame_time = time.time()
    app.new_frame_time = 0
    app.time_elapsed = 0
    app.cap = cv2.VideoCapture(0)
    app.frame = get_frame(app)
    (app.handMask, app.ROI) = checkingColor(app)
    app.roiWin = 75
    app.ratio = 0
    app.command = ''
    ## dino Game
    loadImages(app)
    ############################################################
    app.start = False
    app.difficulty = 1
    app.scoreList = []
    app.score = 0
    app.gameOver = False
    app.timerDelay = 75
    loadImages(app)
    app.dinoCounter = 0
    app.dinoX = 60
    app.dinoY = 165
    app.dinoIsDead = False
    app.dinoIsDucking = False
    app.dinoDirection = True #right direction
    app.dinoIsJumping = False
    app.speedy = 30
    app.gravity = 6
    ## ground ##
    app.groundx = 600
    app.groundy = 180
    ## cloud ##
    app.cloudy = 100
    app.cloudx = random.randint(app.width+app.cloudShape[1], app.width + 150)
    ## cactus ##
    app.cactusInd1 = 0
    app.cactusInd2 = 0
    app.cactiy = 173
    app.cactix = random.randint(app.width+app.cacti_smallShape[1], app.width + 150)
    app.cactix2 = 1.4*app.cactix
    app.gap = 100
    ## bird ##
    app.birdx = random.randint(app.width+app.cacti_smallShape[1], app.width + 150)
    app.birdy = 160
    app.birdCounter = 0
    ################################################################

def get_frame(app):
    ret, frame = app.cap.read()
    scalingFactor = 0.5
    frame = cv2.resize(frame, None, fx = scalingFactor, fy = scalingFactor,
        interpolation = cv2.INTER_AREA)
    frame = cv2.flip(frame, 1)
    return frame

def distance(x,x1,y,y1):
    return np.sqrt((x-x1)**2 + (y-y1)**2)

def checkingColor(app):
    app.smallROIList = [[108, 248],
                        [92, 250],
                        [165, 247], [151, 274], [120, 296],
                        [93, 301], [88, 275], [81, 267]]
    screen_width = 500
    screen_height = 500

    x = int(screen_width//5)
    y = int(screen_height//2)
    # print(f'{int(screen_width//5)}')
    # print(f'{int(screen_width//5)+50}')
    # print(f'{int(screen_width//5)-50}')
    radius = 75
    axes = (radius, radius)
    angle = 0
    startAngle = 90
    endAngle = -90
    color = (255,0,0)
    #print(f'screen_width is {screen_width} and screen_height is {screen_height}')
    ROI = app.frame[y-75:y+75, x-75:x+75]
    cv2.circle(app.frame, (int(screen_width//5), int(screen_height//2)), 
                       75, (0,255,0), 5)
    cv2.ellipse(app.frame,(int(screen_width//5), int(screen_height//2)),
                        axes, angle, startAngle, endAngle, color,thickness = 5)
    org = (0,int(screen_height//4))
    font = cv2.FONT_HERSHEY_SIMPLEX
    if app.time_elapsed <= 20:
        if app.time_elapsed <= 15:
            cv2.putText(app.frame, 'Put hand over the green squares', org, font,  
                    1, (255, 0, 0) ,1, cv2.LINE_AA)     
        elif app.time_elapsed > 15:
            cv2.putText(app.frame, 'Color Registration Complete', org, font,  
                    1, (0, 0, 255) ,1, cv2.LINE_AA)   
                  
    #fgmask = fgbg.apply(ROI)   
    imgHSV = cv2.cvtColor(ROI,cv2.COLOR_BGR2HSV)
    HSV = cv2.cvtColor(app.frame, cv2.COLOR_BGR2HSV)
    h = []
    s = []
    v = []
    for roi in app.smallROIList:
        x,y = roi
        color = HSV[y-2:y+2, x-2:x+2]
        h_mean = np.mean(color[:,:,0])
        s_mean = np.mean(color[:,:,1])
        v_mean = np.mean(color[:,:,2])
        h.append(h_mean)
        s.append(s_mean)
        v.append(v_mean)
    if app.time_elapsed < 15:
        h_min = np.min(h)
        h_max = np.max(h)
        s_min = np.min(s)
        s_max = np.max(s)
        v_min = np.min(v)
        v_max = np.max(v)

        app.lower = np.array([h_min,s_min,v_min])
        app.upper = np.array([h_max,s_max,v_max])

    mask = cv2.inRange(imgHSV,app.lower,app.upper)
    kernel = np.ones((3,3),np.uint8)
    mask = cv2.dilate(mask,kernel,iterations = 1)
    mask = cv2.GaussianBlur(mask, (13,13), 2)
    mask = cv2.erode(mask, kernel, cv2.BORDER_REFLECT, iterations = 2)
    return (mask, ROI)

def drawContour(app):
    CONTOURS, _ = cv2.findContours(app.handMask, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    newContours = []
    for c in CONTOURS:
        area = cv2.contourArea(c)
        #print(area)
        if area > 150*150*0.02:
            newContours.append(c)
    cv2.drawContours(app.ROI, newContours, -1, (0,255,0), 1)
    hull = [cv2.convexHull(c) for c in newContours] 
    cv2.drawContours(app.ROI, hull, -1, (0,0,255), 3)
    
    # Approximate contours to polygons + get bounding circles
    #https://docs.opencv.org/3.4/da/d0c/tutorial_bounding_rects_circles.html
    contours_poly = [None]*len(newContours)
    boundRect = [None]*len(newContours)
    centers = [None]*len(newContours)
    radius = [None]*len(newContours)
    for i, c in enumerate(newContours):
        contours_poly[i] = cv2.approxPolyDP(c, 3, True)
        boundRect[i] = cv2.boundingRect(contours_poly[i])
        centers[i], radius[i] = cv2.minEnclosingCircle(contours_poly[i])
    try:
        center = centers[0]
        r = radius[0]
        r = int(r)
        app.px = int(center[0]) 
        app.py = int(center[1]) + 25
        #print(f'r now is {int(r)} and center now is {int(center[0])} {int(center[1])}')
        cv2.circle(app.ROI, (app.px, app.py), 2, (255,0,0), 5)
    except:
        pass
    #Finding convex defects points
    L = []
    fingerT = []
    try:
        #Drawing all the convex points
        max_cont = max(newContours, key=cv2.contourArea)
        hull = cv2.convexHull(max_cont, returnPoints=False)
        defects = cv2.convexityDefects(max_cont, hull)
        #print(f'we have {len(defects)} defects points')
        #plotting convex hull defects
        for i in range(len(defects)):
            s,e,f,d = defects[i][0]
            x, y = max_cont[f][0]
            xt, yt = max_cont[s][0]
            fingerT.append([xt,yt])
            #print(f'x and y are {x}, {y}')
            L.append([distance(x,app.px,y,app.py),x,y])
            #cv2.circle(app.ROI, (x,y), 2, (0,0,0), 3)
        L.sort()
    except:
        pass

    #window suppressing and eliminate convex defects points that are close to each other
    win = 25
    index = 1
    oldL = copy.deepcopy(L)
    while index < len(L):
        x = L[index-1][1]
        y = L[index-1][2]
        # print(f'ii is {index}')
        # print(f'L before popping is {np.shape(oldL)}')
        # print(f'L after popping is {np.shape(L)}')
        x_comp = L[index][1]
        y_comp = L[index][2]
        x_range = range(x-win, x+win)
        y_range = range(y-win, y+win)
        if x_comp in x_range and y_comp in y_range:
            L.pop(index)
        else: 
            index += 1
    #print(f'oldL list is of shape {np.shape(oldL)}')
    #print(f'L list now is of shape {np.shape(L)}')
    # print(f'L looks like this {L}')     
    #drawing the last 5 close and far points 
    closeL = L[:]
    #Drawing all the defect points after suppresion 
    try:
        farL = L[-1]
        xF = farL[1]
        yF = farL[2]
        #print(f'farL is {farL}')
        for i in range(len(closeL)):
            x = closeL[i][1]
            y = closeL[i][2]
            #print(f'<{x},{y}>')
            #if yF < py: #only draw the finger tips if they are above the palm centers
            cv2.circle(app.ROI, (x,y), 3, (0,255,0), 2)
            cv2.circle(app.ROI, (xF,yF), 10, (0,0,0), 4)
            TargetDistance = distance(xF,app.px,yF,app.py)
            #print(f'The distance from palm center is {TargetDistance}')
            #print(f'And the ratio over the whole ROI is  {TargetDistance/150}')
        return TargetDistance/150
                #cv2.circle(ROI, (xF,yF), 5, (0,0,0), 4)
                #image = cv2.line(ROI, (px,py), (xF,yF), (255,0,0), 3) 
    except: pass

def commandOutput(app):
    font = cv2.FONT_HERSHEY_SIMPLEX
    try:
        if app.ratio > 0.5: 
            #print('Jump')
            cv2.putText(app.frame, 'Jump', (250,250), font,  
                   1, (0, 0, 255), 3, cv2.LINE_AA) 
            return 'w'
        if app.px >= 120:
            cv2.putText(app.frame, 'Right', (250,250), font,  
                   1, (0, 0, 255), 3, cv2.LINE_AA) 
            return 'd'
        if app.px <= 70:
            cv2.putText(app.frame, 'Left', (250,250), font,  
                   1, (0, 0, 255), 3, cv2.LINE_AA) 
            return 'a'
        else:
            #print('stay')
            pass
    except: pass

def showImage(app):
    cv2.imshow("currFrame", app.frame)
    cv2.waitKey(1)

def updateWebcam(app):
    app.frame = get_frame(app)
    (app.handMask, app.ROI) = checkingColor(app)
    app.ratio  = drawContour(app)
    app.command = commandOutput(app)

def drawSmallROI(app, canvas):
    if app.time_elapsed <= 20:
        if app.time_elapsed <= 15:
            for pts in app.smallROIList:
                x,y = pts
                cv2.rectangle(app.frame, (x-2,y-2), (x+2,y+2), (0,255,0), 1)
        elif app.time_elapsed > 15:
            for pts in app.smallROIList:
                x,y = pts
                cv2.rectangle(app.frame, (x-2,y-2), (x+2,y+2), (0,0,255), 1)

def keyPressed(app, event):
    if app.gameOver == False and app.start == True:
        if (app.command == 'a') or (event.key == "a"):  
            print('left')  
            app.dinoX -= 15
            if app.dinoDirection == True: #(right)
                flipDino(app)
                app.dinoDirection = False
        elif (app.command == 'd') or (event.key == "d"): 
            print('Right')
            app.dinoX += 15
            if app.dinoDirection == False: #(left)
                flipDino(app)
                app.dinoDirection = True
        elif (app.command == 'w') or (event.key == 'w'): 
            app.dinoIsJumping = True
        elif (event.key == 's'):
            app.dinoIsDucking = True
        elif (event.key == 'Space'):
            app.dinoIsJumping = True
            app.dinoList = app.runList
    if event.key == 'r':
        appStarted(app)
    if event.key == 'Enter':
        app.start = True
            
def keyReleased(app,event):
    if event.key == 's':
        app.dinoIsDucking = True
    elif event.key != 's':
        app.dinoIsDucking = False
        app.dinoList = app.runList

def timerFired(app):
    if app.gameOver == False and app.start == True:
        if (app.command == 'w'):
            app.dinoIsJumping = True
        if (app.command == 'a'):
            app.dinoX -= 15
            if app.dinoDirection == True: #(right)
                flipDino(app)
                app.dinoDirection = False
        if (app.command == 'd'):
            app.dinoX += 15
            if app.dinoDirection == False: #(left)
                flipDino(app)
                app.dinoDirection = True


    app.new_frame_time = time.time()
    app.time_elapsed = app.new_frame_time - app.prev_frame_time
    updateWebcam(app)

    ## Dino##
    if app.gameOver == False and app.start == True:
        # print(f'the length of cactus list is {len(app.cactiList)}')
        # print(f'app.cactusInd is {app.cactusInd1} and {app.cactusInd2}')
        #print(f'dino position is at <{app.dinoX}, {app.dinoY}> bird is at <{app.birdx},{app.birdy}>')
        updateScore(app)
        groundMoving(app)
        cloudMoving(app)
        cactusMoving(app)
        if app.dinoIsJumping and app.dinoY <= 165:
            jumping(app)
        if app.dinoIsDucking:
            ducking(app)
            app.dinoCounter = (1 + app.dinoCounter) % 2
        elif app.dinoIsDead == False:
            app.dinoCounter = (1 + app.dinoCounter) % 3
        if app.dinoIsDead:
            app.dinoCounter = 3
        if ((abs(app.cactix-app.dinoX)<= 30 and app.cactiy - app.dinoY <= 45) or 
            (abs(app.cactix2-app.dinoX)<= 30 and app.cactiy - app.dinoY <= 45) or 
            (abs(app.birdx - app.dinoX) <= 30 and abs(app.dinoY - app.birdy) <= 20)):
            app.dinoIsDead = True
            app.gameOver = True
        else: app.score += 1
        if app.difficulty >= 4: #if difficulty is greater than 4 then include the flying bird
            flyBird(app)
            app.birdCounter = (app.birdCounter + 1)%2
            #app.cactusInd = random.randint(4,end)

def redrawAll(app, canvas):
    if app.time_elapsed <= 20:
        drawSmallROI(app, canvas)

    cv2.imshow('frame', app.frame)
    cv2.imshow('hand-mask', app.handMask)

    ##Dino ##
    canvas.create_rectangle(0,0,app.width,app.height, fill = 'gray')
    canvas.create_image(app.groundx, app.groundy, image=ImageTk.PhotoImage(app.ground))
    canvas.create_image(app.cactix, app.cactiy, image=ImageTk.PhotoImage(app.cactiList[app.cactusInd1]))
    canvas.create_image(app.cactix2, app.cactiy, image=ImageTk.PhotoImage(app.cactiList[app.cactusInd2]))
    for cloud in app.cloudList:
        canvas.create_image(app.cloudx, app.cloudy, image=ImageTk.PhotoImage(cloud))

    if app.gameOver:
        canvas.create_image(app.dinoX, app.dinoY, image=ImageTk.PhotoImage(app.dinoList[3]))
        canvas.create_image(300,100, image = ImageTk.PhotoImage(app.gameOverImage))
        canvas.create_image(300,130, image = ImageTk.PhotoImage(app.replayIcon))

    # canvas.create_rectangle(app.dinoX - 25//2, app.dinoY-20//2, app.dinoX + 25//2, app.dinoY+20//2, fill = 'blue')
    # canvas.create_rectangle(app.birdx - 25//2, app.birdy-20//2, app.birdx + 25//2, app.birdy+20//2, fill = 'blue')
    
    for i in range(len(app.scoreList)):
        canvas.create_image(500+i*20,70, image = ImageTk.PhotoImage(app.scoreList[i]))
    canvas.create_image(app.dinoX, app.dinoY, image=ImageTk.PhotoImage(app.dinoList[app.dinoCounter]))

    canvas.create_image(app.birdx, app.birdy, image = ImageTk.PhotoImage(app.birdList[app.birdCounter]))
    if app.start == False:
        canvas.create_image(350,100, image = ImageTk.PhotoImage(app.logo))

###################################################
############### CHROME T-REX GAME #################
###################################################
runApp(width=600, height=200)

